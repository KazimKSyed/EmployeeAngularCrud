export interface IEmp {
    code : string;
    name : string;
    gender : string;
    annualSalary:Number;
    dateOfBirth:string;

    //myUDF();
}
